import tkinter as tk
from tkinter import ttk, messagebox
from init_db import inicializar_banco
from db import conectar_bd, fechar_bd
import secretaria
import professor
import aluno


# =======================================================
# CRIAR GRADIENTE NO FUNDO
# =======================================================
def gradient_bg(canvas, width, height, color1, color2):
    r1, g1, b1 = canvas.winfo_rgb(color1)
    r2, g2, b2 = canvas.winfo_rgb(color2)

    r_ratio = float(r2 - r1) / height
    g_ratio = float(g2 - g1) / height
    b_ratio = float(b2 - b1) / height

    for i in range(height):
        nr = int(r1 + (r_ratio * i))
        ng = int(g1 + (g_ratio * i))
        nb = int(b1 + (b_ratio * i))
        color = "#%04x%04x%04x" % (nr, ng, nb)
        canvas.create_line(0, i, width, i, fill=color)


# =======================================================
# LOGIN MODERNO
# =======================================================
def janela_login():
    janela = tk.Tk()
    janela.title("Login - Plataforma Educacional")
    janela.geometry("430x520")
    janela.resizable(False, False)

    # =========================
    # CANVAS COM GRADIENTE
    # =========================
    canvas = tk.Canvas(janela, width=430, height=520, highlightthickness=0)
    canvas.pack(fill="both", expand=True)
    gradient_bg(canvas, 430, 520, "#0A66C2", "#68A1F0")

    # =========================
    # AVATARES (simples)
    # =========================
    avatar_label = tk.Label(janela, bg="#FFFFFF", font=("Arial", 55))
    avatar_label.place(relx=0.5, rely=0.25, anchor="center")

    def atualizar_avatar(tipo):
        if tipo == "secretaria":
            avatar_label.config(text="👩‍💼")
        elif tipo == "professor":
            avatar_label.config(text="👨‍🏫")
        elif tipo == "aluno":
            avatar_label.config(text="👨‍🎓")
        else:
            avatar_label.config(text="❔")

    # =========================
    # CARD (com sombra)
    # =========================
    sombra = tk.Frame(canvas, bg="#234A7A")
    sombra.place(relx=0.5, rely=0.62, anchor="center", width=310, height=350)

    card = tk.Frame(canvas, bg="white")
    card.place(relx=0.5, rely=0.60, anchor="center", width=300, height=340)

    # =========================
    # CAMPOS DE ENTRADA
    # =========================
    tk.Label(card, text="Usuário:", bg="white", font=("Segoe UI", 10)).pack(pady=5)
    entry_usuario = tk.Entry(
        card, width=28, font=("Segoe UI", 11), bg="#F3F4F6",
        relief="flat", highlightthickness=1, highlightbackground="#0A66C2"
    )
    entry_usuario.pack()

    tk.Label(card, text="Senha:", bg="white", font=("Segoe UI", 10)).pack(pady=5)

    # Campo senha + botão mostrar
    senha_frame = tk.Frame(card, bg="white")
    senha_frame.pack()

    entry_senha = tk.Entry(
        senha_frame, width=22, font=("Segoe UI", 11), show="*",
        bg="#F3F4F6", relief="flat", highlightthickness=1, highlightbackground="#0A66C2"
    )
    entry_senha.grid(row=0, column=0, padx=2)

    def toggle_senha():
        if entry_senha.cget("show") == "":
            entry_senha.config(show="*")
            btn_toggle.config(text="👁")
        else:
            entry_senha.config(show="")
            btn_toggle.config(text="🙈")

    btn_toggle = tk.Button(
        senha_frame, text="👁", font=("Segoe UI", 10),
        relief="flat", bg="white", command=toggle_senha
    )
    btn_toggle.grid(row=0, column=1)

    # =========================
    # COMBOBOX TIPO (sempre azul)
    # =========================
    tk.Label(card, text="Entrar como:", bg="white", font=("Segoe UI", 10)).pack(pady=5)

    tipo_var = tk.StringVar()
    combo = ttk.Combobox(
        card, textvariable=tipo_var, state="readonly",
        values=["secretaria", "professor", "aluno"],
        font=("Segoe UI", 10), width=27
    )
    combo.set("Selecione o tipo de usuário")
    combo.pack()

    # Força o fundo AZUL SEMPRE
    style = ttk.Style()
    style.theme_use("clam")
    style.map(
        "TCombobox",
        fieldbackground=[("readonly", "#E8F1FF")],
        background=[("readonly", "#E8F1FF")],
        foreground=[("readonly", "black")]
    )

    # Atualizar avatar ao trocar tipo
    combo.bind("<<ComboboxSelected>>", lambda e: atualizar_avatar(tipo_var.get()))

    # =========================
    # LOGIN FUNCTION
    # =========================
    def validar_login():
        usuario = entry_usuario.get().strip()
        senha = entry_senha.get().strip()
        tipo = tipo_var.get().strip()

        if not usuario or not senha:
            messagebox.showwarning("Atenção", "Preencha todos os campos!")
            return

        if "Selecione" in tipo:
            messagebox.showwarning("Atenção", "Escolha o tipo de usuário!")
            return

        con, cur = conectar_bd()
        cur.execute("SELECT * FROM usuarios WHERE username=%s AND senha=%s", (usuario, senha))
        user = cur.fetchone()
        fechar_bd(con, cur)

        if not user:
            messagebox.showerror("Erro", "Usuário ou senha incorretos!")
            return

        if user["nivel"] != tipo:
            messagebox.showerror("Erro", "Tipo de usuário incorreto!")
            return

        janela.destroy()

        if tipo == "secretaria":
            secretaria.abrir_tela_secretaria()
        elif tipo == "professor":
            professor.abrir_tela_professor(user["nome"])
        else:
            aluno.abrir_tela_aluno(user["nome"])

    # =========================
    # BOTÃO LOGIN
    # =========================
    def hover_in(e):
        login_btn.config(bg="#084A8F")

    def hover_out(e):
        login_btn.config(bg="#0A66C2")

    login_btn = tk.Button(
        card, text="Entrar", bg="#0A66C2", fg="white",
        font=("Segoe UI", 12, "bold"),
        width=20, bd=0, relief="flat",
        command=validar_login
    )
    login_btn.pack(pady=20)
    login_btn.bind("<Enter>", hover_in)
    login_btn.bind("<Leave>", hover_out)

    # Avatar inicial
    atualizar_avatar("none")

    janela.mainloop()


# =======================================================
# START
# =======================================================
if __name__ == "__main__":
    inicializar_banco()
    janela_login()
